nome = input("Digite seu primeiro nome:\n")
print(f"\nBem-vindo(a) ao Codespaces, {nome}!")
