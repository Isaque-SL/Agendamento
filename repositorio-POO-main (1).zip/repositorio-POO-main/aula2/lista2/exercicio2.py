nota1 = int(input("Digite a nota do primeiro bimestre da disciplina:\n"))
nota2 = int(input("Digite a nota do segundo bimestre da disciplina:\n"))
print(f"Média parcial = {((nota1 * 2) + (nota2 * 3)) // 5}")