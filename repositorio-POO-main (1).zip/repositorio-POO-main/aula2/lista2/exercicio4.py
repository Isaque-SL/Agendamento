    frase = input("Digite uma frase:\n")
space = frase.rfind(' ') + 1
print(frase[space:])