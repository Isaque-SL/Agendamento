A = int(input())
B = int(input())
PROD = A * B
print(f"PROD = {PROD}")