nota1 = float(input()) * 3.5
nota2 = float(input()) * 7.5
media = (nota1 + nota2) / 11
print(f"MEDIA = {media:.5f}")