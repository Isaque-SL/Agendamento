tomadas = list(map(int, input().split()))
quantidade = sum(tomadas) - 3
print(quantidade)