num = 0
while num <= 98:
    num += 2
    print(num)
