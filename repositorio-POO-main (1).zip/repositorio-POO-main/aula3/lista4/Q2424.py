X, Y = map(float, input().split())
if 0 <= X <= 432 and 0 <= Y <= 468:
    print("dentro")
else:
    print("fora")
