def maior(x, y, z):
 m = max(x, y, z)
 return m
x, y, z = int(input()), int(input()), int(input())
print(maior(x, y, z))
