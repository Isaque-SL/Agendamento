def maior(x, y):
 m = max(x, y)
 return m
x = int(input())
y = int(input())
print(maior(x, y))
